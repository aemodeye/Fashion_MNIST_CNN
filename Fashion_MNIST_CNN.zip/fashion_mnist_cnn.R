install.packages("keras")
library(keras)
#install tensorflow since it is not installed by default
install_keras()

#Implement the CNN on fashion MNIST dataset

library(keras)

#load the fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()

#prepare the data
c(c(train_images, train_labels), c(test_images, test_labels)) %<-%fashion_mnist

#Reshape and normalize the data
train_images <- array_reshape(train_images, c(nrow(test_images), 28, 28, 1)) / 255
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1)) / 255

#convert labels to categorical
train_labels <- to_categorical(train_labels, 10)
test_labels <- to_categorical(test_labels, 10)

#Build the CNN model
model <- keras_model_sequential()%>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1))%>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_flatten() %>%
  layer_dense(units = 64, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

#Compile the model
model %>% compile(
  optimizer = 'adam'
  loss = 'categorical_crossentropy'
  metrics = c('accuracy')
)

#Train the model
model %>% fit(train_images, train_labels, epochs = 5, batch_size = 64, validation_split = 0.1)

#Evaluate the model
score <- model %>%
evaluate(test_images, test_labels)
cat('Test accuracy:', score$acc)

#Make predictions for the first two test images
predictions <- model %>%
predict(test_images[1:2,,, ])

#Display the image and their predicted labels
par(mfrow = c(1, 2)) #This sets up the plotting area
for (i in 1:2) {
  img <- test_images[i,,,1] #Gets the image data
  label <- which.max(predictions[i, ]) #Gets the predicted label
  true_label <- which.max(test_labels[i, ]) . 1  #Gets the true label
  #Plot the image
  plot(as.raster(img), main = paste("Predicted label:", label, "\nTrue label:", true_label), xlab = "", ylab = "")
}
